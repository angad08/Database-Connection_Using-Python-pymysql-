import pymysql as pm
from tkinter import *
from tkinter import ttk
import random as rd
import tkinter.messagebox as tmm
from PIL import Image,ImageTk
import datetime as dt
from time import strftime
import Pythn_Pckgs as pyp
import smtplib
from email.mime.text import MIMEText as mt
from email.mime.multipart import MIMEMultipart as mmt
smth=dt.datetime.now()
def Expose_Password(C,E):
    if(C.get()==True):
        E["show"]=""
    else:
        E["show"]="*"






















def Selected_AppConsole():
    db=pm.Connect("localhost","root","","ang08_details")
    rs=db.cursor()
    win=Toplevel()
    s=ttk.Style()
    s.theme_use('clam')
    img_1=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Lion.jpg")
    img_2=ImageTk.PhotoImage(img_1)
    iconic_img=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Parrot.jfif")
    iconic_img_1=ImageTk.PhotoImage(iconic_img)
    win.iconphoto(False,iconic_img_1)
    w=(str)(img_1.width)
    h=(str)(img_1.height)
    win.title("ACOUNT DETAILS")
    win.geometry(w+"x"+h)
    Label(win,image=img_2).pack(side=LEFT)
    def Update_Mail_Alert(a,b):
            msg=mmt("Blume Rainforest")
            msg["Subject"]="Welcome To The Jungle Blume"
            msg["From"]="blumephyruss@gmail.com"
            msg["To"]=a
            text="""
            <html>
            <body>
            <b><font size='4' color='green' style='font-family:verdana;'><p align="center">"""f'{b}'"""</p></font></b>
            </html>
            """
            part=mt(text,"html")
            msg.attach(part)
            # creates SMTP session 
            s = smtplib.SMTP('smtp.gmail.com', 587) 
            # start TLS for security 
            s.starttls() 
            # Authentication 
            s.login("blumephyruss@gmail.com", "welcometothejungle") 
            # sending the mail 
            s.sendmail("blumephyruss@gmail.com",a, (str)(msg)) 
            # terminating the session 
            s.quit()
    def Show_Dataset():
        if ACCOUNT_Entry.get()=="" and USERNAME_Entry.get()=="":
            def Delete():
                del_sel=tree.selection()
                for b in del_sel:
                    del_a=tree.set(b,"#1")
                    del_b=tree.set(b,"#2")
                    sq_del_r="DELETE FROM WILD_LIFE WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(del_a,del_b)
                    rs.execute(sq_del_r)
                    db.commit()
                    tree.delete(b)
            def Change():
                sel=tree.selection()
                j=smth.strftime("%H:%M:%S")
                k=smth.strftime(("%Y-%m-%d"))
                if ACCOUNT_Entry.get()!="" and USERNAME_Entry.get()!="":
                    for b in sel:
                        a=tree.set(b,"#1")
                        c=tree.set(b,"#2")
                        if a==ACCOUNT_Entry.get() and c==USERNAME_Entry.get():
                            tmm.showinfo("SAME",f"{a} and {c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(ACCOUNT_Entry.get(),USERNAME_Entry.get(),j,k,a,c)
                            rs.execute(sql)
                            db.commit()
                            if c!=USERNAME_Entry.get():
                                Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            if a==ACCOUNT_Entry.get():
                                tmm.showinfo("SAME",f"{a} Already Same!!!")
                            elif c==USERNAME_Entry.get():
                                tmm.showinfo("SAME",f"{c} Already Same!!!")
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                elif ACCOUNT_Entry.get()=="" and USERNAME_Entry.get()=="":
                    tmm.showwarning("UMMM",f"{account_label_tag['text']} and {username_label_tag['text']} Fields Blank")
                elif ACCOUNT_Entry.get()=="":
                    for b in sel:
                        c=tree.set(b,"#2")
                        if c==USERNAME_Entry.get():
                            tmm.showinfo("SAME",f"{c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE EMAIL_USERNAME_NO='{}'".format(USERNAME_Entry.get(),j,k,c)
                            rs.execute(sql)
                            db.commit()
                            Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                else:
                    for b in sel:
                        a=tree.set(b,"#1")
                        if a==ACCOUNT_Entry.get():
                            tmm.showinfo("SAME",f"{a} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}'".format(ACCOUNT_Entry.get(),j,k,a)
                            rs.execute(sql)
                            db.commit()
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
            col_name="SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='wild_life'"
            rs.execute(col_name)
            db.commit()
            res_col=rs.fetchall()
            data_col="SELECT * FROM wild_life"
            rs.execute(data_col)
            res_data=rs.fetchall()
            db.commit()
            sb_1=Scrollbar(win,bg="white")  
            sb_1.place(x=1348,y=200,height=350)
            sb_2=Scrollbar(win,orient=HORIZONTAL)
            sb_2.place(x=1,y=550,width=1346)
            tree=ttk.Treeview(win,xscrollcommand=sb_2.set,yscrollcommand=sb_1.set)
            tree["columns"]=[(str)(i) for i in range(len(res_col)-1)]
            for i in range(len(res_col)-1):
                tree.column("#"+(str)(i),width=270)
            for i in range(len(res_col)-1):
                for k in range(len(res_col[i])):
                    tree.heading("#"+(str)(i),text=res_col[i][k],anchor=W)
            for i in res_data:
                a=i[0]
                b=i[1]
                c=i[2]
                d=pyp.Encrypt_Seal(i[3],"sha3_512")
                e=i[4]
                f=i[5]
                g=(b,c,d,e,f)
                tree.insert("","end",text=a,value=g)
            Button(win,text="CHANGE DATA",font=("arial",18,"bold"),relief=FLAT,command=Change,fg="#DECC9C",bg="WHITE").place(x=435,y=630)
            Button(win,text="DELETE DATA",font=("arial",18,"bold"),relief=FLAT,command=Delete,fg="#DECC9C",bg="WHITE").place(x=730,y=630)
            tree.place(x=1,y=200,width=1347,height=350)
            sb_1.config(command=tree.yview)
            sb_2.config(command=tree.xview)
        elif ACCOUNT_Entry.get()=="" and not USERNAME_Entry.get()=="":
            def Delete():
                del_sel=tree.selection()
                for b in del_sel:
                    del_a=tree.set(b,"#1")
                    del_b=tree.set(b,"#2")
                    sq_del_r="DELETE FROM WILD_LIFE WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(del_a,del_b)
                    rs.execute(sq_del_r)
                    db.commit()
                    tree.delete(b)
            def Change():
                sel=tree.selection()
                j=smth.strftime("%H:%M:%S")
                k=smth.strftime(("%Y-%m-%d"))
                if ACCOUNT_Entry.get()!="" and USERNAME_Entry.get()!="":
                    for b in sel:
                        a=tree.set(b,"#1")
                        c=tree.set(b,"#2")
                        if a==ACCOUNT_Entry.get() and c==USERNAME_Entry.get():
                            tmm.showinfo("SAME",f"{a} and {c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(ACCOUNT_Entry.get(),USERNAME_Entry.get(),j,k,a,c)
                            rs.execute(sql)
                            db.commit()
                            if c!=USERNAME_Entry.get():
                                Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            if a==ACCOUNT_Entry.get():
                                tmm.showinfo("SAME",f"{a} Already Same!!!")
                            elif c==USERNAME_Entry.get():
                                tmm.showinfo("SAME",f"{c} Already Same!!!")
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                elif ACCOUNT_Entry.get()=="" and USERNAME_Entry.get()=="":
                    tmm.showwarning("UMMM",f"{account_label_tag['text']} and {username_label_tag['text']} Fields Blank")
                elif ACCOUNT_Entry.get()=="":
                    for b in sel:
                        c=tree.set(b,"#2")
                        if c==USERNAME_Entry.get():
                            tmm.showinfo("Same",f"{c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE EMAIL_USERNAME_NO='{}'".format(USERNAME_Entry.get(),j,k,c)
                            rs.execute(sql)
                            db.commit()
                            Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                else:
                    for b in sel:
                        a=tree.set(b,"#1")
                        if a==ACCOUNT_Entry.get():
                            tmm.showinfo("SAME",f"{a} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}'".format(ACCOUNT_Entry.get(),j,k,a)
                            rs.execute(sql)
                            db.commit()
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
            col_name="SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='wild_life'"
            rs.execute(col_name)
            db.commit()
            res_col=rs.fetchall()
            data_col="SELECT * FROM wild_life WHERE EMAIL_USERNAME_NO LIKE'{}%%'".format(USERNAME_Entry.get())
            rs.execute(data_col)
            res_data=rs.fetchall()
            if(len(res_data))==0:
                tmm.showinfo("UMMM",f"NO RECORD OF {USERNAME_Entry.get()} FOUND")
            else:
                db.commit()
                sb_1=Scrollbar(win,bg="white")  
                sb_1.place(x=1348,y=200,height=350)
                sb_2=Scrollbar(win,orient=HORIZONTAL)
                sb_2.place(x=1,y=550,width=1346)
                tree=ttk.Treeview(win,xscrollcommand=sb_2.set,yscrollcommand=sb_1.set)
                tree["columns"]=[(str)(i) for i in range(len(res_col)-1)]
                for i in range(len(res_col)-1):
                    tree.column("#"+(str)(i),width=270)
                for i in range(len(res_col)-1):
                    for k in range(len(res_col[i])):
                        tree.heading("#"+(str)(i),text=res_col[i][k])
                for i in res_data:
                    a=i[0]
                    b=i[1]
                    c=i[2]
                    d=pyp.Encrypt_Seal(i[3],"sha3_512")
                    e=i[4]
                    f=i[5]
                    g=(b,c,d,e,f)
                    tree.insert("","end",text=a,value=g)  
                Button(win,text="CHANGE DATA",font=("arial",18,"bold"),relief=FLAT,command=Change,fg="#DECC9C",bg="WHITE").place(x=435,y=630)
                Button(win,text="DELETE DATA",font=("arial",18,"bold"),relief=FLAT,command=Delete,fg="#DECC9C",bg="WHITE").place(x=730,y=630)
                tree.place(x=1,y=200,width=1347,height=350)
                sb_1.config(command=tree.yview)
                sb_2.config(command=tree.xview)
        elif not ACCOUNT_Entry.get()=="" and USERNAME_Entry.get()=="":
            def Delete():
                del_sel=tree.selection()
                for b in del_sel:
                    del_a=tree.set(b,"#1")
                    del_b=tree.set(b,"#2")
                    sq_del_r="DELETE FROM WILD_LIFE WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(del_a,del_b)
                    rs.execute(sq_del_r)
                    db.commit()
                    tree.delete(b)
            def Change():
                sel=tree.selection()
                j=smth.strftime("%H:%M:%S")
                k=smth.strftime(("%Y-%m-%d"))
                if ACCOUNT_Entry.get()!="" and USERNAME_Entry.get()!="":
                    for b in sel:
                        a=tree.set(b,"#1")
                        c=tree.set(b,"#2")
                        if a==ACCOUNT_Entry.get() and c==USERNAME_Entry.get():
                            tmm.showinfo("SAME",f"{a} and {c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(ACCOUNT_Entry.get(),USERNAME_Entry.get(),j,k,a,c)
                            rs.execute(sql)
                            db.commit()
                            if c!=USERNAME_Entry.get():
                                Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            if a==ACCOUNT_Entry.get():
                                tmm.showinfo("SAME",f"{a} Already Same!!!")
                            elif c==USERNAME_Entry.get():
                                tmm.showinfo("SAME",f"{c} Already Same!!!")
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                elif ACCOUNT_Entry.get()=="" and USERNAME_Entry.get()=="":
                    tmm.showwarning("UMMM",f"{account_label_tag['text']} and {username_label_tag['text']} Fields Blank")
                elif ACCOUNT_Entry.get()=="":
                    for b in sel:
                        c=tree.set(b,"#2")
                        if c==USERNAME_Entry.get():
                            tmm.showinfo("SAME",f"{c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE EMAIL_USERNAME_NO='{}'".format(USERNAME_Entry.get(),j,k,c)
                            rs.execute(sql)
                            db.commit()
                            Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                else:
                    for b in sel:
                        a=tree.set(b,"#1")
                        if a==ACCOUNT_Entry.get():
                            tmm.showinfo("SAME",f"{a} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}'".format(ACCOUNT_Entry.get(),j,k,a)
                            rs.execute(sql)
                            db.commit()
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
            col_name="SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='wild_life'"
            rs.execute(col_name)
            db.commit()
            res_col=rs.fetchall()
            data_col="SELECT * FROM wild_life WHERE ACCOUNT_NAME LIKE '{}%%'".format(ACCOUNT_Entry.get())
            rs.execute(data_col)
            res_data=rs.fetchall()
            if(len(res_data))==0:
                tmm.showinfo("UMMM",f"NO RECORD OF {ACCOUNT_Entry.get()} FOUND")
            else:
                db.commit()
                sb_1=Scrollbar(win,bg="white")  
                sb_1.place(x=1348,y=200,height=350)
                sb_2=Scrollbar(win,orient=HORIZONTAL)
                sb_2.place(x=1,y=550,width=1346)
                tree=ttk.Treeview(win,xscrollcommand=sb_2.set,yscrollcommand=sb_1.set)
                tree["columns"]=[(str)(i) for i in range(len(res_col)-1)]
                for i in range(len(res_col)-1):
                    tree.column("#"+(str)(i),width=270)
                for i in range(len(res_col)-1):
                    for k in range(len(res_col[i])):
                        tree.heading("#"+(str)(i),text=res_col[i][k])
                for i in res_data:
                    a=i[0]
                    b=i[1]
                    c=i[2]
                    d=pyp.Encrypt_Seal(i[3],"sha3_512")
                    e=i[4]
                    f=i[5]
                    g=(b,c,d,e,f)
                    tree.insert("","end",text=a,value=g)  
                Button(win,text="CHANGE DATA",font=("arial",18,"bold"),relief=FLAT,command=Change,fg="#DECC9C",bg="WHITE").place(x=435,y=630)
                Button(win,text="DELETE DATA",font=("arial",18,"bold"),relief=FLAT,command=Delete,fg="#DECC9C",bg="WHITE").place(x=730,y=630)
                tree.place(x=1,y=200,width=1347,height=350)
                sb_1.config(command=tree.yview)
                sb_2.config(command=tree.xview)  
        elif not ACCOUNT_Entry.get()=="" and not USERNAME_Entry.get()=="":
            def Delete():
                del_sel=tree.selection()
                for b in del_sel:
                    del_a=tree.set(b,"#1")
                    del_b=tree.set(b,"#2")
                    sq_del_r="DELETE FROM WILD_LIFE WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(del_a,del_b)
                    rs.execute(sq_del_r)
                    db.commit()
                    tree.delete(b)
            def Change():
                sel=tree.selection()
                j=smth.strftime("%H:%M:%S")
                k=smth.strftime(("%Y-%m-%d"))
                if ACCOUNT_Entry.get()!="" and USERNAME_Entry.get()!="":
                    for b in sel:
                        a=tree.set(b,"#1")
                        c=tree.set(b,"#2")
                        if a==ACCOUNT_Entry.get() and c==USERNAME_Entry.get():
                            tmm.showinfo("SAME",f"{a} and {c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(ACCOUNT_Entry.get(),USERNAME_Entry.get(),j,k,a,c)
                            rs.execute(sql)
                            db.commit()
                            if c!=USERNAME_Entry.get():
                                Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            if a==ACCOUNT_Entry.get():
                                tmm.showinfo("SAME",f"{a} Already Same!!!")
                            elif c==USERNAME_Entry.get():
                                tmm.showinfo("SAME",f"{c} Already Same!!!")
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                elif ACCOUNT_Entry.get()=="" and USERNAME_Entry.get()=="":
                    tmm.showwarning("UMMM",f"{account_label_tag['text']} and {username_label_tag['text']} Fields Blank")
                elif ACCOUNT_Entry.get()=="":
                    for b in sel:
                        c=tree.set(b,"#2")
                        if c==USERNAME_Entry.get():
                            tmm.showinfo("SAME",f"{c} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET EMAIL_USERNAME_NO='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE EMAIL_USERNAME_NO='{}'".format(USERNAME_Entry.get(),j,k,c)
                            rs.execute(sql)
                            db.commit()
                            Update_Mail_Alert(c,f"Email Updated To {USERNAME_Entry.get()} From {c}")
                            tree.set(b,"#2",value=USERNAME_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
                else:
                    for b in sel:
                        a=tree.set(b,"#1")
                        if a==ACCOUNT_Entry.get():
                            tmm.showinfo("SAME",f"{a} Already Present!!!")
                        else:
                            sql="UPDATE wild_life SET ACCOUNT_NAME='{}',ACTIVITY_TIME='{}',ACTIVITY_DATE='{}' WHERE ACCOUNT_NAME='{}'".format(ACCOUNT_Entry.get(),j,k,a)
                            rs.execute(sql)
                            db.commit()
                            tree.set(b,"#1",value=ACCOUNT_Entry.get())
                            tree.set(b,"#4",value=j)
                            tree.set(b,"#5",value=k)
            col_name="SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='wild_life'"
            rs.execute(col_name)
            db.commit()
            res_col=rs.fetchall()
            data_col="SELECT * FROM wild_life WHERE ACCOUNT_NAME  LIKE '{}%%' OR EMAIL_USERNAME_NO LIKE '{}%%'".format(ACCOUNT_Entry.get(),USERNAME_Entry.get())
            rs.execute(data_col)
            res_data=rs.fetchall()
            if(len(res_data))==0:
                tmm.showinfo("UMMM",f"NO RECORD OF {ACCOUNT_Entry.get()} AND {USERNAME_Entry.get()} FOUND")
            else:
                db.commit()
                sb_1=Scrollbar(win,bg="white")  
                sb_1.place(x=1348,y=200,height=350)
                sb_2=Scrollbar(win,orient=HORIZONTAL)
                sb_2.place(x=1,y=550,width=1346)
                tree=ttk.Treeview(win,xscrollcommand=sb_2.set,yscrollcommand=sb_1.set)
                tree["columns"]=[(str)(i) for i in range(len(res_col)-1)]
                for i in range(len(res_col)-1):
                    tree.column("#"+(str)(i),width=270)
                for i in range(len(res_col)-1):
                    for k in range(len(res_col[i])):
                        tree.heading("#"+(str)(i),text=res_col[i][k])
                for i in res_data:
                    a=i[0]
                    b=i[1]
                    c=i[2]
                    d=pyp.Encrypt_Seal(i[3],"sha3_512")
                    e=i[4]
                    f=i[5]
                    g=(b,c,d,e,f)
                    tree.insert("","end",text=a,value=g)  
                Button(win,text="CHANGE DATA",font=("arial",18,"bold"),relief=FLAT,command=Change,fg="#DECC9C",bg="WHITE").place(x=435,y=630)
                Button(win,text="DELETE DATA",font=("arial",18,"bold"),relief=FLAT,command=Delete,fg="#DECC9C",bg="WHITE").place(x=730,y=630)
                tree.place(x=1,y=200,width=1347,height=350)
                sb_1.config(command=tree.yview)
                sb_2.config(command=tree.xview)   
    # C1=BooleanVar()
    ACCOUNT_Entry=StringVar()
    USERNAME_Entry=StringVar()
    # Checkbutton(win,variable=C1,text="OPEN VIEW",padx=1,relief=FLAT,fg="#DECC9C",bg="#e6ac00",font=("papyrus",15,"bold")).place(x=990,y=60,height=30,width=200)
    account_label_tag=Label(win,text="ACCOUNT",font=("Poor Richard","30","bold"),fg="#DECC9C",bg="#e6ac00")
    username_label_tag=Label(win,text="USERNAME",font=("Poor Richard","30","bold"),fg="#DECC9C",bg="#e6ac00")
    Entry(win,textvariable=ACCOUNT_Entry,width=50,fg="#e6ac00",bg="#DECC9C",font=("verdana",10,"bold")).place(x=260,y=6,height=40)
    Entry(win,textvariable=USERNAME_Entry,width=50,fg="#e6ac00",bg="#DECC9C",font=("verdana",10,"bold")).place(x=260,y=95,height=40)
    account_label_tag.place(x=25,y=2)
    username_label_tag.place(x=16,y=90)
    B1=Button(win,text="DISPLAY-DATA",font=("arial",18,"bold"),relief=FLAT,command=lambda:Show_Dataset(),fg="#DECC9C",bg="#e6ac00")
    B1.place(x=750,y=47)
    win.mainloop()



























































































































































def Register():
    root_signup=Toplevel()
    img_sp_1=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/T1.jpg")
    img_sp_2=ImageTk.PhotoImage(img_sp_1)
    ico_sup=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Parrot.jfif")
    ico_sup_1=ImageTk.PhotoImage(ico_sup)
    root_signup.iconphoto(False,ico_sup_1)
    w=(str)(img_sp_1.width)
    h=(str)(img_sp_1.height)
    root_signup.geometry(w+"x"+h)
    root_signup.title("Registration")
    def Confirmation_Mail(b):
        msg=mmt("Blume Rainforest")
        msg["Subject"]="Welcome To The Jungle Blume"
        msg["From"]="blumephyruss@gmail.com"
        msg["To"]=b
        text="""
        <html>
        <head>
        <body>
        <font color='red' size=10 style='bold'>Welcome To The Jungle</font>
        </body>
        </html>
        """
        part=mt(text,"html")
        msg.attach(part)
        
        # creates SMTP session 
        s = smtplib.SMTP('smtp.gmail.com', 587) 
        
        # start TLS for security 
        s.starttls() 
        
        # Authentication 
        s.login("blumephyruss@gmail.com", "welcometothejungle") 
    

    
        # sending the mail 
        s.sendmail("blumephyruss@gmail.com",b, (str)(msg)) 
        # terminating the session 
        s.quit() 
    def generate_code(e1,e2,f):
        if f.get()==True:
            k=pyp.Gen_Rndm_psscde(6,spc=0)
            e1.set(k)
            e2.set(k)
        else:
            e1.set("")
            e2.set("")
    def check_state(event):
            Suggest_Password["state"]=ACTIVE
    def Sign_Up():
        a=reg_account_name.get()
        b=reg_eun.get()
        c=reg_password_sup.get()
        d=reg_cnf_password_sup.get()
        if(len(a)==0):
            Label(root_signup,text=(account_name["text"]+" Can't Be Null"),fg="red",font=("times","15","underline"),bg="#ffc14d").place(x=945,y=95,height=30)
        if(len(b)==0):
            Label(root_signup,text=(eun["text"]+" Can't Be Null"),fg="red",font=("times","15","underline"),bg="#ffc14d").place(x=945,y=185,height=30)
        if(len(c)==0):
            Label(root_signup,text=(password_1["text"]+" Can't Be Null"),fg="red",font=("times","15","underline"),bg="#ffc14d").place(x=945,y=285,height=30)
        if(len(d)==0):
            Label(root_signup,text=(password_2["text"]+" Can't Be Null"),fg="red",font=("times","15","underline"),bg="#ffc14d").place(x=945,y=385,height=30)
        elif((str)(c)==(str)(d)):
            sign_up="SELECT ACCOUNT_NAME,EMAIL_USERNAME_NO FROM WILD_LIFE WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(a,b)
            rs.execute(sign_up)
            db.commit()
            result_signup=rs.fetchall()
            if len(result_signup)!=0:
                tmm.showinfo("Jungle",f"Email/Username {result_signup[0][1]} With Account {result_signup[0][0]} Already Exists")
            else:
                sign_up="INSERT INTO WILD_LIFE (ACCOUNT_NAME,EMAIL_USERNAME_NO,PASSWORD,ACTIVITY_TIME,ACTIVITY_DATE) VALUES('{}','{}','{}','{}','{}')".format(a,b,(pyp.Encrypt_Seal(c,"md5")),(smth.strftime("%H:%M:%S")),(smth.strftime("%Y-%m-%d")))
                rs.execute(sign_up)
                db.commit()
                tmm.showinfo("Welcome To The Jungle","Registration Sucecssfully Done!Now Go And Log In")
                if "@gmail.com" in b:
                    Confirmation_Mail(b)
        else:
            tmm.showerror("Incorrect Passwords","{} and {} Are Wrong".format(password_1["text"],password_2["text"]))
    def Toggle_PassShow():
        if(c1.get()==True):
            E3["show"]=""
            E4["show"]=""
        else:
            E3["show"]="*"
            E4["show"]="*"
    

    Label(root_signup,image=img_sp_2).pack(side=LEFT)
    reg_account_name=StringVar()
    reg_eun=StringVar()
    reg_password_sup=StringVar()
    reg_cnf_password_sup=StringVar()
    c1=BooleanVar()
    c2=BooleanVar()
    account_name=Label(root_signup,text="Account Name",font=("Poor Richard","30","bold"),bg="#ffc14d",fg="#1d1d1d")
    eun=Label(root_signup,text="Username",font=("Poor Richard","30","bold"),bg="#ffc14d",fg="#1d1d1d")
    password_1=Label(root_signup,text="Password",font=("Poor Richard","30","bold"),bg="#ffc14d",fg="#1d1d1d")
    password_2=Label(root_signup,text="Confirm Password",font=("Poor Richard","30","bold"),bg="#ffc14d",fg="#1d1d1d")
    Checkbutton(root_signup,text="Show",command=lambda:Toggle_PassShow(),variable=c1,font=("papyrus",15,"bold"),bg="#ffc14d",fg="#1d1d1d").place(x=850,y=500,width=90,height=55)
    Entry(root_signup,textvariable=reg_account_name,width=35,bd=2,fg="#ffc14d",bg="#1d1d1d",insertbackground="#ffc14d",font=("verdana",10,"bold")).place(x=620,y=95,height=30,bordermode=OUTSIDE)
    Entry(root_signup,textvariable=reg_eun,width=35,bd=2,fg="#ffc14d",bg="#1d1d1d",insertbackground="#ffc14d",font=("verdana",10,"bold")).place(x=620,y=185,height=30,bordermode=OUTSIDE)
    E3=Entry(root_signup,textvariable=reg_password_sup,width=35,bd=2,show="*",fg="#ffc14d",bg="#1d1d1d",insertbackground="#ffc14d",font=("verdana",10,"bold"))
    E4=Entry(root_signup,textvariable=reg_cnf_password_sup,show="*",width=35,bd=2,fg="#ffc14d",bg="#1d1d1d",insertbackground="#ffc14d",font=("verdana",10,"bold"))
    E3.bind('<Button-1>',check_state)
    account_name.place(x=340,y=90,height=40)
    eun.place(x=420,y=170)
    password_1.place(x=430,y=270)
    password_2.place(x=290,y=370)
    E3.place(x=620,y=285,height=30,bordermode=OUTSIDE)
    E4.place(x=620,y=385,height=30,bordermode=OUTSIDE)
    Sign_Up_Bttn=Button(root_signup,text="Sign_Up",command=Sign_Up,relief=FLAT,fg="#000000",bg="#ffc14d",width=10,height=1,font=("papyrus",15,"bold"))
    Suggest_Password=Checkbutton(root_signup,text="Suggest Password",relief=FLAT,variable=c2,fg="#000000",bg="#ffc14d",font=("papyrus",15,"bold"),state=DISABLED,command=lambda:generate_code(reg_cnf_password_sup,reg_password_sup,c2))
    Sign_Up_Bttn.place(x=650,y=500)
    Suggest_Password.place(x=960,y=385,height=30)
    root_signup.mainloop()


























































def Forgot_Password():
    def new_psswd():
        def Mail(a,b):
            msg=mmt("Blume Rainforest")
            msg["Subject"]="Welcome To The Jungle Blume"
            msg["From"]="blumephyruss@gmail.com"
            msg["To"]=a
            text="""
            <html>
            <style>
            .container_1
            {
            padding:2px;
            }
            .card_1
            {
            box-shadow: 0 10px 10px 0 rgba(0.8,0.8,0.8,0.8);
            transition: 0.8s;
            width: 10%;
            border-radius: 10px;
            }
            .card_1:hover
            {
            box-shadow: 0 12px 14px 0 rgba(0,0,0,0.4);
            }
            img
            {
            border-radius: 10px 10px 0 0;
            }
            .container_2
            {
            padding:2px;
            }
            .card_2
            {
            box-shadow: 0 16px 18px 0 rgba(0.5,0.5,0.5,0.5);
            transition: 0.8s;
            width: 10%;
            border-radius: 10px;
            }
            </style>
            <body>
            <center>
            <div class='card_1' style='background-color:#ffc14d;'>
            <div class='container_1'>
            <h4><b><font size='4' style='font-family:verdana;'><p align='center'>Your OTP</p></font></b></h4> 
            </div>
            </div>
            <div class='card_2' style='background-color:#1d1d1d;'>
            <div class='container_2'>
            <b><font size='4' color='#ffc14d' style='font-family:verdana;'><p align="center">"""f'{b}'"""</p></font></b>
            </font>
            </div>
            </div>
            </center>
            </html>
            """
            part=mt(text,"html")
            msg.attach(part)
            # creates SMTP session 
            s = smtplib.SMTP('smtp.gmail.com', 587) 
            # start TLS for security 
            s.starttls() 
            # Authentication 
            s.login("blumephyruss@gmail.com", "welcometothejungle") 
            # sending the mail 
            s.sendmail("blumephyruss@gmail.com",a, (str)(msg)) 
            # terminating the session 
            s.quit()
        def Pass_Mail(a):
            msg=mmt("Blume Rainforest")
            msg["Subject"]="Welcome To The Jungle Blume"
            msg["From"]="blumephyruss@gmail.com"
            msg["To"]=a
            text="""
            <html>
            <body>
            <b><font size='4' color='green' style='font-family:verdana;'><p align="center">"""f'Password Changed Sucessfully On <font color="violet">{smth.strftime("%d %b %Y")}</font> <font color="gray">@</font><font color="red">{smth.strftime("%H:%M:%S")}</font>'"""</p></font></b>
            </html>
            """
            part=mt(text,"html")
            msg.attach(part)
            # creates SMTP session 
            s = smtplib.SMTP('smtp.gmail.com', 587) 
            # start TLS for security 
            s.starttls() 
            # Authentication 
            s.login("blumephyruss@gmail.com", "welcometothejungle") 
            # sending the mail 
            s.sendmail("blumephyruss@gmail.com",a, (str)(msg)) 
            # terminating the session 
            s.quit()
        def Set_Passwd():
            def show():
                if c.get()==True:
                    new_pass_now["show"]=""
                    cnf_new_pass_now["show"]=""
                else:
                    new_pass_now["show"]="*"
                    cnf_new_pass_now["show"]="*"
            def generate_new_pssd(a,b,i):
                if i.get()==True:
                    k=pyp.Gen_Rndm_psscde(6,spc=0)
                    a.set(k)
                    b.set(k)
                else:
                    a.set("")
                    b.set("")

            def Update_Password(a,b):
                if new_pass_now.get()=="" and cnf_new_pass_now.get()=="":
                    tmm.showerror("Field Blank",f"{new_password_set['text']} And {cnf_new_password_set['text']} Field Blank")
                elif new_pass_now.get()=="":
                    tmm.showerror("Blank Field",f"{new_password_set['text']} Field Blank")
                elif cnf_new_pass_now.get()=="":
                    tmm.showerror("Blank Field",f"{cnf_new_password_set['text']} Field Blank")
                elif new_pass_now.get()==cnf_new_pass_now.get():
                    pass_chng="UPDATE WILD_LIFE SET PASSWORD='{}' WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(pyp.Encrypt_Seal(new_pass_now.get(),"md5"),a,b)
                    rs.execute(pass_chng)
                    db.commit()
                    Pass_Mail(rec_eun.get())
                    tmm.showinfo("Password Change",f"Password For {rec_eun.get()} Changed Sucessfully @{smth.strftime('%H:%M')}")
                else:
                    tmm.showerror("Wrong","Passwords Dont Match")
            if rec_otp.get()==(str)(new_pssd):
                a=StringVar()
                b=StringVar()
                c=BooleanVar()
                i=BooleanVar()
                new_password_set=Label(new_pass_rec,text="Password",font=("Poor Richard","30","bold"),bg="#99ff33",fg="#ffffff")
                cnf_new_password_set=Label(new_pass_rec,text="Confirm Password",font=("Poor Richard","30","bold"),bg="#99ff33",fg="#ffffff")
                new_pass_now=Entry(new_pass_rec,textvariable=a,show="*",width=35,bd=2,fg="#99ff33",bg="#ffffff",insertbackground="#99ff33",font=("verdana",10,"bold"))
                cnf_new_pass_now=Entry(new_pass_rec,textvariable=b,show="*",width=35,bd=2,fg="#99ff33",bg="#ffffff",insertbackground="#99ff33",font=("verdana",10,"bold"))
                h=Checkbutton(new_pass_rec,variable=c,text="show",command=show,font=("papyrus",15,"bold"),bg="#99ff33",fg="#ffffff")
                j=Checkbutton(new_pass_rec,variable=i,text="create",command=lambda:generate_new_pssd(a,b,i),font=("papyrus",15,"bold"),bg="#99ff33",fg="#ffffff")
                new_pass_now.place(x=640,y=200,height=50,width=250)
                cnf_new_pass_now.place(x=640,y=280,height=50,width=250)
                new_password_set.place(x=460,y=200)
                cnf_new_password_set.place(x=320,y=280)
                h.place(x=550,y=450,width=235)
                j.place(x=550,y=500,width=235)
                Up_pass=Button(new_pass_rec,command=lambda:Update_Password(rec_account_name.get(),rec_eun.get()),text="Change Password",relief=FLAT,bg="#99ff33",fg="#ffffff",width=15,height=1,font=("papyrus",15,"bold"))
                Up_pass.place(x=550,y=390)
                E_3.delete(0,END)
                E_3["state"]=DISABLED
                New_Pass_Button["state"]=DISABLED
            elif rec_otp.get()=="":
                tmm.showwarning("Security Concern!!!",f"{L_3['text']} Blank!!!\nCheck Your Mail For OTP")
            else:
                tmm.showerror("","OTP Invalid")
        if not rec_account_name.get()=="" and not rec_eun.get()=="":
            recqul="SELECT ACCOUNT_NAME,EMAIL_USERNAME_NO FROM wild_life WHERE ACCOUNT_NAME='{}' AND EMAIL_USERNAME_NO='{}'".format(rec_account_name.get(),rec_eun.get())
            rs.execute(recqul)
            db.commit()
            recql_result=rs.fetchone()
            if recql_result!=None:
                new_pass_rec=Toplevel()
                new_img_sp_1=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Python.jpg")
                new_img_sp_2=ImageTk.PhotoImage(new_img_sp_1)
                new_ico_sup=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Parrot.jfif")
                new_ico_sup_1=ImageTk.PhotoImage(new_ico_sup)
                new_pass_rec.iconphoto(False,new_ico_sup_1)
                w=(str)(img_sp_1.width)
                h=(str)(img_sp_1.height)
                new_pass_rec.geometry(w+"x"+h)
                new_pass_rec.title("Registration")
                Label(new_pass_rec,image=new_img_sp_2).pack(side=LEFT)
                new_pssd=rd.randint(100000,999999)
                rec_otp=StringVar()
                L_3=Label(new_pass_rec,text="OTP",font=("Poor Richard","30","bold"),bg="#99ff33",fg="#ffffff")
                New_Pass_Button=Button(new_pass_rec,text="Check OTP",command=Set_Passwd,relief=FLAT,bg="#99ff33",fg="#ffffff",width=10,height=1,font=("papyrus",15,"bold"))
                E_3=Entry(new_pass_rec,textvariable=rec_otp,width=35,bd=2,fg="#99ff33",bg="#ffffff",insertbackground="#99ff33",font=("verdana",10,"bold"))
                L_3.place(x=5,y=5)
                E_3.place(x=90,y=5,height=50,width=250)
                New_Pass_Button.place(x=380,y=4)
                Mail(rec_eun.get(),(str)(new_pssd))
                new_pass_rec.mainloop()
            else:
                tmm.showerror("",f"{L_1['text']} OR {L_2['text']} UNKNOWN!!!!")
        elif rec_account_name.get()=="" and rec_eun.get()=="":
            tmm.showerror("Blank Fields",f"{L_1['text']} and {L_2['text']} Fields Blank")
        elif rec_account_name.get()=="":
            tmm.showerror("Blank Fields",f"{L_1['text']} Field Blank")
        elif rec_eun.get()=="":
            tmm.showerror("Blank Fields",f"{L_2['text']} Field Blank")

    recover_root=Toplevel()
    img_sp_1=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Elephant.jpg")
    img_sp_2=ImageTk.PhotoImage(img_sp_1)
    ico_sup=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Parrot.jfif")
    ico_sup_1=ImageTk.PhotoImage(ico_sup)
    recover_root.iconphoto(False,ico_sup_1)
    w=(str)(img_sp_1.width)
    h=(str)(img_sp_1.height)
    recover_root.geometry(w+"x"+h)
    recover_root.title("Registration")
    Label(recover_root,image=img_sp_2).pack(side=LEFT)
    rec_account_name=StringVar()
    rec_eun=StringVar()
    L_1=Label(recover_root,text="ACCOUNT",font=("Poor Richard","30","bold"),bg="#9b986b",fg="#ffffbf")
    L_2=Label(recover_root,text="EMAIL/USERNAME",font=("Poor Richard","30","bold"),bg="#9b986b",fg="#ffffbf")
    E_1=Entry(recover_root,textvariable=rec_account_name,width=35,bd=2,fg="#ffffbf",bg="#9b986b",insertbackground="#ffffbf",font=("verdana",10,"bold"))
    E_2=Entry(recover_root,textvariable=rec_eun,width=35,bd=2,fg="#ffffbf",bg="#9b986b",insertbackground="#ffffbf",font=("verdana",10,"bold"))
    B=Button(recover_root,text="Submit",command=new_psswd,relief=FLAT,bg="#9b986b",fg="#ffffbf",width=10,height=1,font=("papyrus",15,"bold"))
    L_1.place(x=350,y=100)
    L_2.place(x=195,y=200)
    E_1.place(x=570,y=100,height=50,width=250)
    E_2.place(x=570,y=200,height=50,width=250)
    B.place(y=320,x=480)
    recover_root.mainloop()






















































































































































root=Tk()
root.trial=3
ico_11=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Parrot.jfif")
ico_22=ImageTk.PhotoImage(ico_11)
root.iconphoto(False,ico_22)
image_1=Image.open("D:/Update Drive/Blume/Python/Tkinter Apps/Database/Login/Leopard.jpg")
photo_1=ImageTk.PhotoImage(image_1)
w=(str)(image_1.width)
h=(str)(image_1.height)
root.geometry(w+"x"+h)
root.title("Login Page")
label = Label(root,image = photo_1)
label.pack(side=LEFT)
db=pm.connect("localhost","root","","ang08_details")
rs=db.cursor()
def times(): 
    string = strftime('%A %B %d %Y\n %H:%M:%S %p')
    Current_LBL.config(text = string) 
    Current_LBL.after(1000, times)
def Login():
    try:
        login_check="SELECT ACCOUNT_NAME,EMAIL_USERNAME_NO,PASSWORD FROM WILD_LIFE WHERE EMAIL_USERNAME_NO='{}' AND PASSWORD='{}'".format(e1.get(),pyp.Encrypt_Seal(e2.get(),"md5"))
        rs.execute(login_check)
        db.commit()
        result=rs.fetchone()
        if len(e1.get())==0:
            Label(root,text=(L2["text"]+" Can't Be Null"),fg="red",font=("times","15","underline"),bg="#ffee92").place(x=1005,y=285,height=25)
        if len(e2.get())==0:
            Label(root,text=(L3["text"]+" Can't Be Null"),fg="red",font=("times","15","underline"),bg="#ffee92").place(x=1010,y=390,height=25)
        if(e1.get()==result[1] and pyp.Encrypt_Seal(e2.get(),"md5")==result[2]): 
            tmm.showinfo("Welcome!!!",f"{result[0]} LOGIN SUCESSFUL")
            Selected_AppConsole()
    except:
        if(root.trial>0):
            tmm.showwarning("Warning",f"{root.trial} Trials Remaining")
            root.trial-=1
        else:
            tmm.showerror("Invalid","Too Many Wrong Attempts,Try Again Later!!!")
            exit()
Current_LBL=Label(root,font=("impact",20,"bold"),fg="#ffee92",bg="black")
Current_LBL.place(x=10,y=5)
times()
L1=Label(root,text="DATABASE SYSTEM",font=("papyrus",20,"bold"),fg="#ffee92",bg="black")
L2=Label(root,text="Username",font=("Poor Richard","30","bold"),bg="#ffee92",fg="#1d1d1d")
L3=Label(root,text="Password",font=("Poor Richard","30","bold"),bg="#ffee92",fg="#1d1d1d")
e1=StringVar()
e2=StringVar()
c1=BooleanVar()
Entry(root,textvariable=e1,width=35,bd=2,fg="#ffee92",bg="#1d1d1d",font=("verdana",10,"bold")).place(x=680,y=318,height=30)
E2=Entry(root,show="*",textvariable=e2,width=35,bd=2,fg="#ffee92",bg="#1d1d1d",font=("verdana",10,"bold"))
B1=Button(root,text="Login",command=Login,relief=FLAT,fg="#000000",bg="#ffee92",width=10,height=1,font=("papyrus",15,"bold"))
B2=Button(root,text="Sign Up",command=Register,relief=FLAT,fg="#000000",bg="#ffee92",width=10,height=1,font=("papyrus",15,"bold"))
Checkbutton(root,text="Show",command=lambda:Expose_Password(c1,E2),variable=c1,font=("papyrus",15,"bold"),fg="#000000",bg="#ffee92").place(x=1020,y=490,width=90,height=30)
b_1=Button(root,text="Forgot Password",font=("papyrus",15,"bold"),fg="#000000",bg="#ffee92",relief=FLAT,command=Forgot_Password)
E2.place(x=680,y=390,height=30)
L1.place(x=500,y=5)
L2.place(x=480,y=308,height=40)
L3.place(x=493,y=380,height=40)
B1.place(x=570,y=470)
B2.place(y=470,x=780)
b_1.place(x=570,y=570,width=370)
root.mainloop()