import random as rd
from tkinter import *
def Gen_Rndm_psscde(a,spc=0):
        j=""
        a1="abcdefghijklmnopqrstuvwxyz"
        a2="1234567890"
        a3="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        a4="@#$"
        a5=[a1,a2,a3]
        a6=[a1,a2,a3,a4]
        if (spc=="N") or (spc==0) or (spc=="n"):
            for i in range(a):
                k=rd.choice(a5)
                j=j+rd.choice(k)
            return j
        elif (spc=="Y") or (spc==1) or (spc=="y"):
            for i in range(a):
                k=rd.choice(a6)
                j=j+rd.choice(k)
            return j
        else:
            return "Invalid Commad"
            exit()
def Encrypt_Seal(m,n):
	import hashlib as hlb
	SHA1=hlb.sha1(m.encode("utf-8")).hexdigest()
	SHA224=hlb.sha224(m.encode("utf-8")).hexdigest()
	SHA256=hlb.sha256(m.encode("utf-8")).hexdigest()
	SHA384=hlb.sha384(m.encode("utf-8")).hexdigest()
	SHA512=hlb.sha512(m.encode("utf-8")).hexdigest()
	SHA3_224=hlb.sha3_224(m.encode("utf-8")).hexdigest()
	SHA3_256=hlb.sha3_256(m.encode("utf-8")).hexdigest()
	SHA3_384=hlb.sha3_384(m.encode("utf-8")).hexdigest()
	SHA3_512=hlb.sha3_512(m.encode("utf-8")).hexdigest()
	MD5=hlb.md5(m.encode("utf-8")).hexdigest()
	SHAKE_128=hlb.shake_128(m.encode("utf-8")).hexdigest(8)
	SHAKE_256=hlb.shake_256(m.encode("utf-8")).hexdigest(8)
	BLAKE2B=hlb.blake2b(m.encode("utf-8")).hexdigest()
	BLAKE2S=hlb.blake2s(m.encode("utf-8")).hexdigest()
	if(n=="sha1"):
		return SHA1
	elif(n=="sha224"):
		return SHA224
	elif(n=="sha256"):
		return SHA256
	elif(n=="sha384"):
		return SHA384
	elif(n=="sha512"):
		return SHA512
	elif(n=="sha3_224"):
		return SHA3_224
	elif(n=="sha3_256"):
		return SHA3_256
	elif(n=="sha3_384"):
		return SHA3_384
	elif(n=="sha3_512"):
		return SHA3_512
	elif(n=="md5"):
		return MD5
	elif(n=="shke_128"):
		return SHKE_128
	elif(n=="shke_256"):
		return SHKE_256
	elif(n=="blake2b"):
		return BLAKE2B
	elif(n=="blake2s"):
		return BLAKE2S
	elif(n=="HELP" or n=="help" or n=="h" or n=="H"):
		uc=hlb.algorithms_guaranteed
		print("Available Algorithms Are:")
		c=0
		for u in uc:
			c=c+1
			print("{}.{}".format(c,u))
		exit()
	else:
		print("Unsupported Hash Format!!!!")
		exit()
if __name__=="__main__":
	Encrypt_Seal(m,n)
	Gen_Rndm_psscde(a,lbl,spc)